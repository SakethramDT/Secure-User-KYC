// import React from "react";

// In Completion.js
// const Completion = ({ status, onDone }) => {
//   const isApproved = ['approved', 'completed'].includes(status);
  
//   return (
//     <div className="completion">
//       {isApproved ? (
//         <>
//           <h2>✅ KYC Completed Successfully!</h2>
//           <p>Your verification was approved.</p>
//         </>
//       ) : (
//         <>
//           <h2>❌ KYC Rejected</h2>
//           <p>Your verification was not approved.</p>
//         </>
//       )}
      
//     </div>
//   );
// };

// export default Completion;







































