// DocumentUpload.js
import React, { useState, useEffect, useRef } from "react";
import "./DocumentUpload.css";

const DocumentUpload = ({ formData = {}, setFormData, onNext, onBack }) => {
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);

  const frontInputRef = useRef(null);
  const backInputRef = useRef(null);

  useEffect(() => {
    // Clear any stale error if username is missing (session expired)
    if (!formData?.username) setError(null);
  }, [formData]);

  const handleFileChange = (field, e) => {
    const file = e.target.files && e.target.files[0];
    if (!file) return;
    setError(null);
    if (typeof setFormData === "function") {
      setFormData((prev) => ({ ...(prev || {}), [field]: file }));
    }
  };

  const removeFile = (field, inputRef) => {
    if (typeof setFormData === "function") {
      setFormData((prev) => ({ ...(prev || {}), [field]: null }));
    }
    if (inputRef?.current) inputRef.current.value = "";
  };

  const validateFile = (file) => {
    if (!file) return "File is required";
    if (file.size > 10 * 1024 * 1024) return "File is too large (max 10MB)";
    const validTypes = ["image/jpeg", "image/jpg", "image/png", "application/pdf"];
    if (!validTypes.includes(file.type)) return "Invalid file type. Use JPG, PNG, or PDF";
    return null;
  };

  const handleSubmit = async () => {
    
    if (!formData?.username) {
      setError("Session expired. Please login again.");
      return;
    }

    const frontError = validateFile(formData.document_front);
    const backError = validateFile(formData.document_back);

    if (frontError || backError) {
      setError(frontError || backError);
      return;
    }

    setLoading(true);
    setError(null);

    try {
      const form = new FormData();

      // Append files and simple values. Files will be appended as-is.
      Object.entries(formData || {}).forEach(([key, value]) => {
        if (value === undefined || value === null) return;
        // If value is a File or Blob use it as-is
        if (value instanceof File || value instanceof Blob) {
          form.append(key, value);
        } else if (typeof value === "object") {
          // avoid appending big nested objects — stringify small objects
          try {
            form.append(key, JSON.stringify(value));
          } catch {
            // ignore
          }
        } else {
          form.append(key, String(value));
        }
      });

      const base = process.env.REACT_APP_BACKEND_URL || "";
      // const base = "10.0.0.1:3000";
      const resp = await fetch(`${base}/api/users`, {
        method: "POST",
        body: form,
      });

      // parse safely
      let data = {};
      try {
        data = await resp.json();
      } catch {
        data = {};
      }

      if (!resp.ok) {
        throw new Error(data.error || `Upload failed (HTTP ${resp.status})`);
      }

      const updated = {
        ...(formData || {}),
        documentUrl: data.document_url || null,
        documentBackUrl: data.document_back_url || null,
        roomId: data.room_id || null,
        agent: data.agent || null,
      };

      // update parent state
      if (typeof setFormData === "function") setFormData(updated);

      // navigate to schedule via onNext (parent should switch to schedule step)
      if (typeof onNext === "function") onNext(updated);
    } catch (err) {
      console.error("Upload error:", err);
      setError(err?.message || "Upload failed. Please try again.");
    } finally {
      setLoading(false);
    }
  };

  const formatFileSize = (bytes) => {
    if (!bytes) return "0 Bytes";
    const k = 1024;
    const sizes = ["Bytes", "KB", "MB", "GB"];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + " " + sizes[i];
  };

  return (
    <div className="document-upload-container">
      <div className="document-upload-header">
        <h2>Document Upload</h2>
        <p>Please upload clear photos of both sides of your government-issued ID</p>
      </div>

      <div className="upload-sections">
        {/* Front */}
        <div className="upload-section">
          <div className="dotted-box">
            {!formData?.document_front ? (
              <div className="upload-interface">
                <div className="upload-icon">
                  {/* svg */}
                  <svg width="50" height="50" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                    <path d="M14 2H6C4.9 2 4.01 2.9 4.01 4L4 20C4 21.1 4.89 22 5.99 22H18C19.1 22 20 21.1 20 20V8L14 2ZM16 18H8V16H16V18ZM16 14H8V12H16V14ZM13 9V3.5L18.5 9H13Z" fill="#c7a047" />
                  </svg>
                </div>
                <h3>Front of ID</h3>
                <p className="section-description">Upload the front side of your ID document</p>

                <div className="file-upload-area">
                  <input
                    id="document-front"
                    ref={frontInputRef}
                    type="file"
                    accept=".jpeg,.jpg,.png,.pdf"
                    onChange={(e) => handleFileChange("document_front", e)}
                    disabled={loading}
                  />
                  <label htmlFor="document-front" className="choose-file-button">Choose File</label>
                </div>
                <p className="upload-subtext">or drag and drop your image here</p>
              </div>
            ) : (
              <div className="file-details">
                <div className="upload-icon">
                  <svg width="50" height="50" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                    <path d="M14 2H6C4.9 2 4.01 2.9 4.01 4L4 20C4 21.1 4.89 22 5.99 22H18C19.1 22 20 21.1 20 20V8L14 2ZM16 18H8V16H16V18ZM16 14H8V12H16V14ZM13 9V3.5L18.5 9H13Z" fill="#c7a047" />
                  </svg>
                </div>
                <div className="file-info">
                  <h4>{formData.document_front.name}</h4>
                  <p>{formatFileSize(formData.document_front.size)}</p>
                </div>
                <button className="remove-button" onClick={() => removeFile("document_front", frontInputRef)}>
                  Remove
                </button>
              </div>
            )}
          </div>
        </div>

        {/* Back */}
        <div className="upload-section">
          <div className="dotted-box">
            {!formData?.document_back ? (
              <div className="upload-interface">
                <div className="upload-icon">
                  <svg width="50" height="50" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                    <path d="M14 2H6C4.9 2 4.01 2.9 4.01 4L4 20C4 21.1 4.89 22 5.99 22H18C19.1 22 20 21.1 20 20V8L14 2ZM16 18H8V16H16V18ZM16 14H8V12H16V14ZM13 9V3.5L18.5 9H13Z" fill="#c7a047" />
                  </svg>
                </div>
                <h3>Back of ID</h3>
                <p className="section-description">Upload the back side of your ID document</p>

                <div className="file-upload-area">
                  <input
                    id="document-back"
                    ref={backInputRef}
                    type="file"
                    accept=".jpeg,.jpg,.png,.pdf"
                    onChange={(e) => handleFileChange("document_back", e)}
                    disabled={loading}
                  />
                  <label htmlFor="document-back" className="choose-file-button">Choose File</label>
                </div>
                <p className="upload-subtext">or drag and drop your image here</p>
              </div>
            ) : (
              <div className="file-details">
                <div className="upload-icon">
                  <svg width="50" height="50" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                    <path d="M14 2H6C4.9 2 4.01 2.9 4.01 4L4 20C4 21.1 4.89 22 5.99 22H18C19.1 22 20 21.1 20 20V8L14 2ZM16 18H8V16H16V18ZM16 14H8V12H16V14ZM13 9V3.5L18.5 9H13Z" fill="#c7a047" />
                  </svg>
                </div>
                <div className="file-info">
                  <h4>{formData.document_back.name}</h4>
                  <p>{formatFileSize(formData.document_back.size)}</p>
                </div>
                <button className="remove-button" onClick={() => removeFile("document_back", backInputRef)}>
                  Remove
                </button>
              </div>
            )}
          </div>
        </div>
      </div>

      <div className="requirements-section">
        <h3>Document Requirements:</h3>
        <ul>
          <li>Clear, high-resolution images</li>
          <li>All text must be clearly visible</li>
          <li>No glare or shadows</li>
          <li>Accepted formats: JPG, PNG, PDF</li>
          <li>Maximum file size: 10MB per document</li>
        </ul>
      </div>

      {error && <div className="error-message">{error}</div>}

      <div className="navigation-buttons">
        <button className="back-button" onClick={onBack} disabled={loading}>
          Back
        </button>

        <button
          className="continue-button"
          onClick={handleSubmit}
          disabled={loading || !formData?.document_front || !formData?.document_back}
        >
          {loading ? "Uploading..." : "Continue to Schedule"}
        </button>
      </div>
    </div>
  );
};

export default DocumentUpload;
