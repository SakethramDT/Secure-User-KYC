// ReviewConfirm.js
import React, { useState } from "react";
import { useNavigate } from "react-router-dom"; // make sure react-router-dom is installed
import "./ReviewConfirm.css";

const formatDateTime = (isoDate, timeLabel) => {
  if (!isoDate) return "Not selected";
  try {
    const date = new Date(isoDate.length === 10 ? isoDate + "T00:00:00" : isoDate);
    const options = { year: "numeric", month: "long", day: "numeric" };
    const dateStr = date.toLocaleDateString(undefined, options);
    return timeLabel ? `${dateStr} ${timeLabel}` : dateStr;
  } catch {
    return isoDate;
  }
};

const formatDate = (isoDate) => {
  if (!isoDate) return "—";
  try {
    const date = new Date(isoDate.length === 10 ? isoDate + "T00:00:00" : isoDate);
    const options = { year: "numeric", month: "long", day: "numeric" };
    return date.toLocaleDateString(undefined, options);
  } catch {
    return isoDate;
  }
};

const mask = (val = "") => {
  const s = String(val || "");
  if (!s) return "—";
  if (s.length <= 4) return "****";
  return `${s.slice(0, 3)}${"*".repeat(Math.max(0, s.length - 5))}${s.slice(-2)}`;
};

export default function ReviewConfirm({ formData = {}, onBack = () => {}, setFormData }) {
  const navigate = useNavigate();

  const [loading, setLoading] = useState(false);
  const [errorMsg, setErrorMsg] = useState(null);
  const [successModal, setSuccessModal] = useState(false);

  const {
    name,
    email,
    priority,
    day_date,
    time_label,
    officer_name,
    officer_id,
    assigned_agent_username,
    assigned_agent_id,
    user_id,
    dob,
    gender,
    nationality,
    id_number,
    id_issue_date,
    id_expiry_date,
    document_front_url,
    document_back_url,
    document_id,
    slot_index
  } = formData || {};

  const displayOfficerName = officer_name || assigned_agent_username || "To be assigned";
  const displayOfficerId = officer_id || assigned_agent_id || "—";

  const handleSchedule = async () => {
    setErrorMsg(null);
    setLoading(true);

    try {
      if (!user_id || !day_date || !time_label) {
        setErrorMsg("Missing required details (user, date, or time).");
        setLoading(false);
        return;
      }

      const [startPart, endPart] = time_label.split("-").map((x) => x.trim());
      const start_time = new Date(`${day_date}T${startPart}:00`).toISOString();
      let duration_minutes = 30;
      if (endPart) {
        const end_time = new Date(`${day_date}T${endPart}:00`);
        duration_minutes = Math.round((end_time - new Date(start_time)) / 60000);
      }

      const payload = {
        user_id,
        start_time,
        duration_minutes,
        document_id: document_id || null,
        slot_index,
        day_date,
        document_front_url,
        document_back_url,
      };

      const base = process.env.REACT_APP_BACKEND_URL || "";
      const res = await fetch(`${base}/api/book`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Accept: "application/json",
          "Idempotency-Key": `idem_${Date.now()}_${Math.random().toString(36).slice(2, 10)}`
        },
        body: JSON.stringify(payload)
      });

      if (res.status === 201 || res.status === 200) {
        const data = await res.json();
        if (typeof setFormData === "function") {
          setFormData((prev) => ({
            ...prev,
            appointment: data.appointment,
            assigned_agent_id: data.assigned_agent_id,
            assigned_agent_username: data.assigned_agent_username,
            status: "scheduled",
          }));
        }
        setSuccessModal(true);
      } else {
        const body = await res.json().catch(() => ({}));
        setErrorMsg(body.error || `Failed to schedule (code ${res.status}).`);
      }
    } catch (err) {
      console.error("Schedule error:", err);
      setErrorMsg("Network/server error while scheduling appointment.");
    } finally {
      setLoading(false);
    }
  };

  const closeModal = () => {
    setSuccessModal(false);
    navigate("/login");
  };

  return (
    <div className="rc-wrapper">
      <div className="rc-header">
        <center><h2>Review & Confirm</h2></center>
      </div>

      <div className="rc-cards">
        <div className="rc-card rc-card--left">
          <div className="rc-card-title"><span>Customer Details</span></div>
          <div className="rc-card-body">
            <dl>
              <dt>Name</dt><dd>{name || "—"}</dd>
              <dt>Email</dt><dd>{email || "—"}</dd>
              {/* <dt>Phone</dt><dd>{phone || "—"}</dd> */}
              <dt>ID</dt><dd>{(user_id)}</dd>
              <dt>Date of Birth</dt><dd>{formatDate(dob)}</dd>
              <dt>Gender</dt><dd>{gender || "—"}</dd>
              <dt>Nationality</dt><dd>{nationality || "—"}</dd>
            </dl>
          </div>
        </div>

        <div className="rc-card rc-card--right">
          <div className="rc-card-title"><span>Session Details</span></div>
          <div className="rc-card-body">
            <dl>
              <dt>Scheduled Date & Time</dt>
              <dd>{formatDateTime(day_date, time_label)}</dd>

              <dt>Assigned Officer</dt>
              <dd>{displayOfficerName}</dd>

              {/* <dt>ID</dt>
              <dd>{displayOfficerId}</dd> */}

              <dt>Documents</dt>
              <dd>
                <div className="rc-docs">
                  <div className="rc-doc-item">
                    <div className="rc-doc-label">Front</div>
                    {document_front_url ? (
                      <img src={document_front_url} alt="Front Document" className="rc-doc-img" />
                    ) : (
                      <div className="rc-doc-placeholder">No image</div>
                    )}
                  </div>
                  <div className="rc-doc-item">
                    <div className="rc-doc-label">Back</div>
                    {document_back_url ? (
                      <img src={document_back_url} alt="Back Document" className="rc-doc-img" />
                    ) : (
                      <div className="rc-doc-placeholder">No image</div>
                    )}
                  </div>
                </div>
              </dd>
            </dl>
          </div>
        </div>
      </div>

      {errorMsg && <div style={{ color: "red", marginTop: 8 }}>{errorMsg}</div>}

      <div className="rc-actions">
        <button className="rc-btn rc-btn--secondary" onClick={onBack} disabled={loading}>
          Previous
        </button>
        <button className="rc-btn rc-btn--primary" onClick={handleSchedule} disabled={loading}>
          {loading ? "Scheduling..." : "Schedule Session"}
        </button>
      </div>

      {/* Success Modal */}
      {successModal && (
        <div className="modal-overlay">
          <div className="modal">
            <h3> Appointment Scheduled Successfully!</h3>
            <p>Your video KYC session has been booked for:</p>
            <p><strong>{formatDateTime(day_date, time_label)}</strong></p>
            <p>Officer: <strong>{displayOfficerName}</strong></p>
            <button onClick={closeModal} className="rc-btn rc-btn--primary">Close</button>
          </div>
        </div>
      )}
    </div>
  );
}
